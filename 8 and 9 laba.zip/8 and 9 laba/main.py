import csv
import sqlite3
connection = sqlite3.connect('laba9.db')
cursor = connection.cursor()

cursor.execute('''create table if not exists Klientt(
               id  integer primary key autoincrement,
               fio text)''')

cursor.execute('''create table if not exists Postavshik(
                id integer primary key autoincrement,
                NN integer,
                FIO text)''')

cursor.execute('''create table if not exists Tovar(
                id integer primary key autoincrement,
                name text,
                id_postavshik integer references Postavshik(id),
                kolvo integer,
                id_klient integer references Klientt(id))''')

cursor.execute('''create table if not exists Rab(
                id  integer primary key autoincrement,
                fio text)''')

cursor.execute('''create table if not exists Postavki(
                id integer primary key autoincrement,
                data_time text,
                id_postavshik integer references Posravshik(id),
                id_tovar integer references Tovar(id),
                kolvo integer,
                id_rab integer references Rab(id))''')


with open('venv/Test.csv', 'r', newline='', encoding='utf-8') as file:
    reader = csv.DictReader(file)
    for row in reader:
        if row['fio']:
            cursor.execute('''INSERT INTO Klientt(fio) values ((?));''', (row['fio'],))

with open('venv/Data/Klientt.csv', 'w', newline='', ) as file:
    writer = csv.writer(file)
    writer.writerow(['fio'])
    for i in cursor.execute('''SELECT fio from Klientt'''):
        writer.writerow(i)

with open('venv/Postavshik.csv', 'r', newline='', encoding='utf-8') as file:
    reader = csv.DictReader(file)
    for row in reader:
        if row['NN'] and row['FIO']:
            cursor.execute('''INSERT INTO Postavshik(NN, FIO) values ((?),(?));''', (row['NN'], row['FIO']))

with open('venv/Data/Postavshikk.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['NN', 'fio'])
    for i in cursor.execute('''select NN,fio from Postavshik'''):
        writer.writerow(i)

with open('venv/Tovar.csv', 'r', newline='', encoding='utf-8') as file:
    reader = csv.DictReader(file)
    for row in reader:
        if row['name'] and row['id_postavshik'] and row['kolvo'] and row['id_klient']:
            cursor.execute('''INSERT INTO Tovar(name, id_postavshik, kolvo, id_klient) values ((?),(?),(?),(?));''',
                           (row['name'], row['id_postavshik'],row['kolvo'],row['id_klient']))

with open('venv/Data/Tovar.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['name', 'id_postavshik', 'kolvo', 'id_klient'])
    for i in cursor.execute('''select name,id_postavshik,kolvo,id_klient from Tovar'''):
        writer.writerow(i)

with open('venv/Rab.csv', 'r', newline='', encoding='utf-8') as file:
    reader = csv.DictReader(file)
    for row in reader:
        if row['fio']:
            cursor.execute('''INSERT INTO Rab(fio) values ((?));''',(row['fio'],))

with open('venv/Data/Rab.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['fio'])
    for i in cursor.execute('''select fio from Rab'''):
        writer.writerow(i)

with open('venv/Postavki.csv', 'r', newline='', encoding='utf-8') as file:
    reader = csv.DictReader(file)
    for row in reader:
        if row['data_time'] and row['id_postavshik'] and row['id_tovar'] and row['kolvo'] and row['id_rab']:
            cursor.execute('''INSERT INTO Postavki(data_time, id_postavshik, id_tovar, kolvo, id_rab)
             values ((?),(?),(?),(?),(?));''',
                           (row['data_time'], row['id_postavshik'],row['id_tovar'],row['kolvo'],row['id_rab']))

with open('venv/Data/Postavki.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['data_time', 'id_tovar', 'kolvo', 'id_rab'])
    for i in cursor.execute('''select data_time,id_tovar, kolvo,id_rab from Postavki'''):
        writer.writerow(i)

connection.commit()
cursor.close()